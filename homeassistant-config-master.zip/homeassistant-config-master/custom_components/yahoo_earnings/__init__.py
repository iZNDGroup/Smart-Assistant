"""The yahoo_earnings sensor component."""
