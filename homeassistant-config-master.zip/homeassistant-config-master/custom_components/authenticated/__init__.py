"""The authenticated component."""


class AuthenticatedBaseException(Exception):
    """Base exception for Authenticated."""
